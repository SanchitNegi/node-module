<?php
class CategoriesAppController extends AppController {
    
        function beforeFilter(){
            parent::beforeFilter(); 
            
        }
    
}
?>